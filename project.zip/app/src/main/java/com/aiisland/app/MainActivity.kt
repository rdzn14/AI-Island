package com.aiisland.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Screen() }
    }

    override fun onResume() {
        super.onResume()
        granted = Settings.canDrawOverlays(this)
    }

    @Composable
    private fun Screen() {
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        MaterialTheme(colorScheme = darkColorScheme()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F1319))
                    .systemBarsPadding()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Robot(Mood.HAPPY, 96.dp)
                Spacer(Modifier.height(16.dp))
                Text("AI Island", color = Color.White, fontSize = 24.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (granted) "Kebenaran overlay: sudah" else "Kebenaran overlay: belum",
                    color = Color(0xFF9AA3B2)
                )
                Spacer(Modifier.height(24.dp))
                Button(onClick = {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }) { Text("Beri kebenaran overlay") }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) {
                        ask.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    if (Settings.canDrawOverlays(this@MainActivity)) {
                        ContextCompat.startForegroundService(
                            this@MainActivity,
                            Intent(this@MainActivity, OverlayService::class.java)
                        )
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "Beri kebenaran overlay dulu",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }) { Text("Mulakan island") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    stopService(Intent(this@MainActivity, OverlayService::class.java))
                }) { Text("Hentikan") }
            }
        }
    }
}
